<?php
/**
 * Copyright 2018-present, MageExchange. All rights reserved.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageexchange.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageexchange.com/license-agreement
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to a
 * newer version in the future. This file should be treated as a core file.
 *
 * @category    MageExchange
 * @package     MageExchange_Base
 * @copyright   Copyright (c) Mageexchange (https://www.mageexchange.com/)
 * @license     https://www.mageexchange.com/license-agreement
 */

namespace MageExchange\Base\Block;

use MageExchange\Base\Helper\Modules;
use Magento\Backend\Block\Context;
use Magento\Backend\Model\Auth\Session;
use Magento\Framework\Data\Form\Element\AbstractElement;
use Magento\Framework\Module\ModuleListInterface;
use Magento\Framework\View\Helper\Js;
use Magento\Framework\View\LayoutFactory;

class InstalledModules extends \Magento\Config\Block\System\Config\Form\Fieldset
{
    /**
     * @var Modules
     */
    protected $meHelper;

    /**
     * @var ModuleListInterface
     */
    private $moduleList;

    /**
     * @var LayoutFactory
     */
    private $layoutFactory;
    /**
     * @var \Magento\Framework\View\Element\BlockInterface
     */
    private $_fieldRenderer;

    /**
     * InstalledModules constructor.
     * @param Context $context
     * @param Modules $helper
     * @param Session $authSession
     * @param Js $jsHelper
     * @param ModuleListInterface $moduleList
     * @param LayoutFactory $layoutFactory
     * @param array $data
     */
    public function __construct(
        Context $context,
        Modules $helper,
        Session $authSession,
        Js $jsHelper,
        ModuleListInterface $moduleList,
        LayoutFactory $layoutFactory,
        array $data = []
    ) {
        parent::__construct($context, $authSession, $jsHelper, $data);

        $this->meHelper = $helper;
        $this->moduleList = $moduleList;
        $this->layoutFactory = $layoutFactory;
    }

    /**
     * @param AbstractElement $element
     * @return string
     */
    public function render(AbstractElement $element)
    {
        $html = $this->_getHeaderHtml($element);

        $modules = $this->moduleList->getNames();

        $dispatchResult = new \Magento\Framework\DataObject($modules);
        $modules = $dispatchResult->toArray();
        $meFeedModuleData = $this->meHelper->getFeedData();

        sort($modules);

        foreach ($modules as $module) {
            if (strstr($module, 'MageExchange_') === false) {
                continue;
            }

            $html .= $this->_getFieldHtml($element, $module, $meFeedModuleData);
        }
        $html .= $this->_getFooterHtml($element);

        return $html;
    }

    /**
     * @return \Magento\Framework\View\Element\BlockInterface
     */
    protected function _getFieldRenderer()
    {
        if (empty($this->_fieldRenderer)) {
            $this->_fieldRenderer = $this->_layout->createBlock(
                \Magento\Config\Block\System\Config\Form\Field::class
            );
        }

        return $this->_fieldRenderer;
    }

    /**
     * @param $fieldset
     * @param $moduleName
     * @param $meFeedModuleData
     * @return mixed
     */
    protected function _getFieldHtml($fieldset, $moduleName, $meFeedModuleData)
    {
        $module = $this->meHelper->getModuleInfo($moduleName);
        $moduleNameStripped = str_replace('MageExchange_', '', $moduleName);
        $updateIsAvailable = false;

        if (array_key_exists($moduleName, $meFeedModuleData)) {
            if ($module['version'] !== $meFeedModuleData[$moduleName]['version']) {
                $updateIsAvailable = true;
            }
        }

        $isAvailableUpdate = ($updateIsAvailable) ? "Update Available (v" . $meFeedModuleData[$moduleName]['version'] . ')' : "Latest Version";
        $moduleNameStripped = ($updateIsAvailable) ? '<a href="' . $this->meHelper::ME_DASHBOARD . '" target="_blank">' . $moduleNameStripped . '</a>' : $moduleNameStripped;

        $field = $fieldset->addField(
            $moduleName,
            'label',
            [
                'name' => 'groups[modules_disable_output][fields][' . $moduleName . '][value]',
                'label' => $moduleNameStripped,
                'value' =>  'v' . $module['version'] . ' - ' . $isAvailableUpdate
            ]
        )->setRenderer(
            $this->_getFieldRenderer()
        );

        return $field->toHtml();
    }
}

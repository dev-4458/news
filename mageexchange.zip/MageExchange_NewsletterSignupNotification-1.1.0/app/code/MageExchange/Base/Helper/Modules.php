<?php
/**
 * Copyright 2018-present, MageExchange. All rights reserved.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageexchange.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageexchange.com/license-agreement
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to a
 * newer version in the future. This file should be treated as a core file.
 *
 * @category    MageExchange
 * @package     MageExchange_Base
 * @copyright   Copyright (c) Mageexchange (https://www.mageexchange.com/)
 * @license     https://www.mageexchange.com/license-agreement
 */

namespace MageExchange\Base\Helper;

use Magento\Framework\App\CacheInterface;
use Magento\Framework\Escaper;
use Magento\Framework\Filesystem\Driver\File;
use Magento\Framework\Module\Dir\Reader;
use Magento\Framework\Serialize\SerializerInterface;
use SimpleXMLElement;
use Zend\Http\Client\Adapter\Curl;
use Zend\Http\Response as HttpResponse;
use Zend\Uri\Http as HttpUri;

class Modules
{
    const MAGEEXCHANGE_FEED = 'https://www.mageexchange.com/media/feed/mageexchange-feed.xml';
    const ME_MODULES = 'mageexchange_modules';
    const ME_DASHBOARD = 'https://www.mageexchange.com/downloadable/customer/products/';

    /**
     * @var File
     */
    private $filesystem;

    /**
     * @var Curl
     */
    private $curl;

    /**
     * @var SerializerInterface
     */
    private $serializer;

    /**
     * @var CacheInterface
     */
    private $cache;

    /**
     * @var Reader
     */
    private $moduleReader;

    /**
     * @var Escaper
     */
    private $escaper;

    /**
     * Modules constructor.
     * @param CacheInterface $cache
     * @param Reader $moduleReader
     * @param File $filesystem
     * @param Curl $curl
     * @param SerializerInterface $serializer
     * @param Escaper $escaper
     */
    public function __construct(
        CacheInterface $cache,
        Reader $moduleReader,
        File $filesystem,
        Curl $curl,
        SerializerInterface $serializer,
        Escaper $escaper
    ) {
        $this->filesystem = $filesystem;
        $this->serializer = $serializer;
        $this->curl = $curl;
        $this->cache = $cache;
        $this->moduleReader = $moduleReader;
        $this->escaper = $escaper;
    }

    /**
     * @return array|bool|float|int|string|null
     */
    public function getFeedData()
    {
        $isCached = $this->cache->load(self::ME_MODULES);
        if ($isCached === false) {
            $this->cacheFeedData();
            $isCached = $this->cache->load(self::ME_MODULES);
        }
        $moduleFeedData = $this->serializer->unserialize($isCached);

        return $moduleFeedData;
    }

    private function cacheFeedData() : void
    {
        $moduleData = [];
        $feed = $this->getMEFeed();
        if ($feed && $feed->channel && $feed->channel->item) {
            foreach ($feed->channel->item as $item) {
                $code = $this->escaper->escapeHtml((string)$item->code);

                if (!isset($moduleData[$code])) {
                    $moduleData[$code] = [];
                }

                $name = $this->escaper->escapeHtml((string)$item->title);
                $version = str_replace('v', '', $this->escaper->escapeHtml((string)$item->version));

                $moduleData[$code] = [
                    'name'     => $name,
                    'link'      => $this->escaper->escapeUrl((string)($item->link)),
                    'version'  => $version
                ];
            }

            if ($moduleData) {
                $this->cache->save($this->serializer->serialize($moduleData), self::ME_MODULES);
            }
        }
    }

    /**
     * @return bool|SimpleXMLElement
     */
    private function getMEFeed()
    {
        try {
            if ($this->curl === null) {
                $this->curl = new CurlClient();
            }
            $url = new HttpUri(self::MAGEEXCHANGE_FEED);

            $this->curl->setOptions(
                [
                    'timeout' => 5
                ]
            );

            $this->curl->connect($url->getHost(), $url->getPort());
            $this->curl->write('GET', $url, 1.0);
            $data = HttpResponse::fromString($this->curl->read());
            $this->curl->close();
            $xml = new SimpleXMLElement($data->getContent());
        } catch (\Exception $e) {
            return false;
        }

        return $xml;
    }

    /**
     * @param $moduleCode
     * @return array|bool|float|int|string|null
     */
    public function getModuleInfo($moduleCode)
    {
        try {
            $moduleDir = $this->moduleReader->getModuleDir('', $moduleCode);
            $composerFile = $moduleDir . '/composer.json';
            $composerContents = $this->filesystem->fileGetContents($composerFile);
            $json = $this->serializer->unserialize($composerContents);
        } catch (\Magento\Framework\Exception\FileSystemException $e) {
            $json = [];
        }

        return $json;
    }
}

<?php
/**
 * Copyright 2018-present, MageExchange. All rights reserved.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageexchange.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageexchange.com/license-agreement
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to a
 * newer version in the future. This file should be treated as a core file.
 *
 * @category    MageExchange
 * @package     MageExchange_NewsletterSignupNotification
 * @copyright   Copyright (c) Mageexchange (https://www.mageexchange.com/)
 * @license     https://www.mageexchange.com/license-agreement
 */

namespace MageExchange\NewsletterSignupNotification\Plugin\Newsletter\Model;

class Subscriber
{
    public function __construct(\Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig)
    {
        $this->scopeConfig = $scopeConfig;
    }

    public function beforeSendConfirmationSuccessEmail(\Magento\Newsletter\Model\Subscriber $subject)
    {
        if ($this->scopeConfig->getValue(
            'newsletter/subscription/disable_newsletter_email',
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        )) {
            $subject->setImportMode(true);
        }
    }
}

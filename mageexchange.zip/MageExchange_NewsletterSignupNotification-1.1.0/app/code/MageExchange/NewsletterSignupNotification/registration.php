<?php
/**
 * Copyright 2018-present, MageExchange. All rights reserved.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageexchange.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageexchange.com/license-agreement
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this module to a
 * newer version in the future. This file should be treated as a core file.
 *
 * @category    MageExchange
 * @package     MageExchange_NewsletterSignupNotification
 * @copyright   Copyright (c) Mageexchange (https://www.mageexchange.com/)
 * @license     https://www.mageexchange.com/license-agreement
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'MageExchange_NewsletterSignupNotification',
    __DIR__
);
